

function App() {

  return (
    <>
    <h1>Hello Dojo !</h1>
    <p >things I Need to do</p>
    <ul>
      <li>Learn react</li>
      <li>Climb mt.Everest</li>
      <li>Run a marathon</li>
      <li>Feed the dogs</li>
    </ul>

    </>
  )
}

export default App
